const textArea= document.getElementById('content');
const cCount1=document.getElementById('cCount');
const wCount1=document.getElementById('wCount');
const sCount1=document.getElementById('sCount');
const pCount1=document.getElementById('pCount');
const keywords1=document.getElementById('keys1');
const keywords2=document.getElementById('keys2');
const keywords3=document.getElementById('keys3');
const keywords4=document.getElementById('keys4');
const keywords5=document.getElementById('keys5');
const keywords6=document.getElementById('keys6');
const keywords7=document.getElementById('keys7');
const keywords8=document.getElementById('keys8');
const keywords9=document.getElementById('keys9');
const keywords10=document.getElementById('keys10');
var counts={};
var keys=[];

textArea.oninput=()=>
{
    if(textArea.value==0){
        counts={};
        keys=[];
    }
    const txt=textArea.value;
    
    let c=textArea.value;
    cCount1.textContent=c.replace(/\s/g, '').length;

    let words=textArea.value.split(' ').filter((item)=>{
        return item!='';
    });
    wCount1.textContent=words.length;

    let sens=textArea.value.split('.').filter((item)=>{
        return item!='';
    });
    sCount1.textContent=(sens.length);

    let para=textArea.value.replace(/\n$/gm, '').split(/\n/);
    pCount1.textContent=para.length;

    var tok=txt.split(/\W+/);
    for(var i=0;i<tok.length;i++){
        var word=tok[i].toLowerCase();
        if (!/\d+/.test(word)){
        if(counts[word]===undefined){
            counts[word]=1;
            keys.push(word);
        }else{
            counts[word]=counts[word]+1;
        }
    }
    }

    keys.sort(compare);

    function compare(a,b){
        var counta=counts[a];
        var countb=counts[b];
        return countb-counta;
    }
    if(textArea.value!=0){
    keywords1.innerText=(keys[0] + "-" +counts[keys[0]]);
    keywords2.innerText=(keys[1] + "-" +counts[keys[1]]);
    keywords3.innerText=(keys[2] + "-" +counts[keys[2]]);
    keywords4.innerText=(keys[3] + "-" +counts[keys[3]]);
    keywords5.innerText=(keys[4] + "-" +counts[keys[4]]);
    keywords6.innerText=(keys[5] + "-" +counts[keys[5]]);
    keywords7.innerText=(keys[6] + "-" +counts[keys[6]]);
    keywords8.innerText=(keys[7] + "-" +counts[keys[7]]);
    keywords9.innerText=(keys[8] + "-" +counts[keys[8]]);
    keywords10.innerText=(keys[9] + "-" +counts[keys[9]]);
    }
    
}
