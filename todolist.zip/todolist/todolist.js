const todoinput =document.querySelector(".todo-input");
const todobutton=document.querySelector(".todo-button");
const todolist=document.querySelector(".todo-list");
const todopirority=document.querySelector('select');
const fliterbutton=document.querySelector(".fliter");

todobutton.addEventListener('click',addtodo);
todolist.addEventListener('click',deleteCheck)
fliterbutton.addEventListener('click',flitertodo);

function addtodo(event){

    event.preventDefault();

    const todoDiv = document.createElement('div');
    todoDiv.classList.add("todo");

    const newTodo=document.createElement('li');
    newTodo.innerText=todoinput.value;
    newTodo.classList.add('todo-item');
    todoDiv.appendChild(newTodo);

    const newTodo1=document.createElement('div');
    newTodo1.innerText=todopirority.value;
    newTodo1.classList.add('todo-priority');
    todoDiv.appendChild(newTodo1);

    const completebutton=document.createElement('button');
    completebutton.innerHTML='<i class="fas fa-check"></i>';
    completebutton.classList.add('complete-btn');
    todoDiv.appendChild(completebutton);

    const trashbutton=document.createElement('button');
    trashbutton.innerHTML='<i class="fas fa-trash"></i>';
    trashbutton.classList.add('trash-btn');
    todoDiv.appendChild(trashbutton);

    todolist.appendChild(todoDiv);

    todoinput.value="";

    if(todopirority.value=="LOW"){
        todoDiv.classList.toggle("low-back");
    }
    if(todopirority.value=="MEDIUM"){
        todoDiv.classList.toggle("medium-back");
    }
    if(todopirority.value=="HIGH"){
        todoDiv.classList.toggle("high-back");
    }
}


function deleteCheck (e){
    const item=e.target;
    
    if(item.classList[0]=== "trash-btn"){
        const todo=item.parentElement;
        todo.classList.toggle("deleted")
        todo.addEventListener('transitionend',function(){
            todo.remove();
        });
    }

    if(item.classList[0]==="complete-btn"){
        const todo=item.parentElement;
        todo.classList.toggle("completed");
    }
}

function flitertodo(e){
    e.preventDefault();
    const todos=todolist.childNodes;
    todos.forEach(function(todo){
        switch(e.target.innerText){
                 case "ALL":
                todo.style.display="flex";
                break;
                case "LOW":
                if(todo.classList.contains("low-back")){
                    todo.style.display="flex";
                }    
                else{
                    todo.style.display="none";
                }
                break;
                case "MEDIUM":
                if(todo.classList.contains("medium-back")){
                    todo.style.display="flex";
                }    
                else{
                    todo.style.display="none";
                }
                break;
                case "HIGH":
                if(todo.classList.contains("high-back")){
                    todo.style.display="flex";
                }    
                else{
                    todo.style.display="none";
                }
                break;
        }

    });

}
