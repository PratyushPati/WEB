
    const slider=document.querySelector('.slider')
    const sliderimages=document.querySelectorAll('.slider img');

    const prevbtn=document.querySelector('#prevbtn');
    const nextbtn=document.querySelector('#nextbtn');

    let c=1;
    const size= sliderimages[0].width;

    slider.style.transform='translateX('+(-size*c)+'px)';

    nextbtn.addEventListener('click',()=>{
        slider.style.transition="transform 0.4s ease-in-out";
        c++;
        slider.style.transform='translateX('+(-size*c)+'px)';
    });

    prevbtn.addEventListener('click',()=>{
        slider.style.transition="transform 0.4s ease-in-out";
        c--;
        slider.style.transform='translateX('+(-size*c)+'px)';
    });

    slider.addEventListener('transitionend',()=>{
        if(sliderimages[c].id === 'lastclone'){
            slider.style.transition="none";
            c=sliderimages.length-2;
            slider.style.transform='translateX('+(-size*c)+'px)';
        }
        if(sliderimages[c].id === 'firstclone'){
            slider.style.transition="none";
            c=sliderimages.length-c;
            slider.style.transform='translateX('+(-size*c)+'px)';
        }
    });
