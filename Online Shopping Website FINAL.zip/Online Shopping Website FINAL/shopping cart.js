var removeCartItemButtons = document.getElementsByClassName('btn-danger');
for (var i = 0; i < removeCartItemButtons.length; i++) {
    var button = removeCartItemButtons[i];
    button.addEventListener('click', function(event){
        var buttonlicked=event.target;
        buttonlicked.parentElement.parentElement.remove();
        updateCarttotal();
    });
}
document.getElementsByClassName('btn-purchase')[0].addEventListener('click',purchaseclicked)
function purchaseclicked(){
    alert('Thank you for your purchase.')
    var cartitems=document.getElementsByClassName('cart-items')[0]
    while(cartitems.hasChildNodes()){
        cartitems.removeChild(cartitems.firstChild)
    }
    updateCarttotal();
}
function updateCarttotal(){
    var cartItemConatiner=document.getElementsByClassName('cart-items')[0]
    var cartRows=cartItemConatiner.getElementsByClassName('cart-row')
    var total=0
    for (var i = 0; i < cartRows.length; i++){
        var cartRow=cartRows[i];
        var priceElement=cartRow.getElementsByClassName('cart-price')[0]
        var quantityElemetn=cartRow.getElementsByClassName('cart-quantity-input')[0]
        var price=parseFloat(priceElement.innerText.replace('Rs ',''));
        var quantity=quantityElemetn.value
        total=total+(price*quantity);
    }
    document.getElementsByClassName('cart-total-price')[0].innerText='Rs '+total;
}

var quantityInput=document.getElementsByClassName('cart-quantity-input')
for (var i = 0; i < quantityInput.length; i++) {
    var input=quantityInput[i];
    input.addEventListener('change',quantitychanged)
}
function quantitychanged(event){
    var input=event.target
    if(isNaN(input.value)||input.value<=0){
        input.value=1
    }
    updateCarttotal();
}

var addtocartbutton=document.querySelectorAll('.btn-add')
for (var i = 0; i < addtocartbutton.length; i++) {
    var button=addtocartbutton[i];
    button.addEventListener('click',addtocartclicked)
}
function addtocartclicked(event){
    var button=event.target
    var shopitem=button.parentElement
    var title= shopitem.getElementsByClassName('product-title')[0].innerText
    var price=shopitem.getElementsByClassName('product-price')[0].innerText
    var imageSrc=shopitem.getElementsByClassName('product-img')[0].src
    additemtocart(title,price,imageSrc)
    updateCarttotal();
}

function additemtocart(title,price,imageSrc){
    
    var cartRo=document.createElement('div')
    cartRo.classList.add('cart-row')
    var cartites=document.getElementsByClassName('cart-items')[0]
    var cartitemnames=cartites.getElementsByClassName('cart-item-title')
    for(var i=0;i<cartitemnames.length;i++){
        if(cartitemnames[i].innerText==title){
            alert('Already Added')
            return
        }
    }
    var cartRowContents=` <div class="cart-item cart-column">
                <img src="${imageSrc}" alt="" class="cart-item-image" width="100" height="100">
                <span class="cart-item-title">${title}</span>
            </div>
            <span class="cart-price cart-column">${price}</span>
            <div class="cart-quantity cart-column">
                <input type="number" class="cart-quantity-input" value="1">
                <button class="btn btn-danger" type="button">REMOVE</button>
            </div>
            </div>`
     cartRo.innerHTML=cartRowContents       
    cartites.append(cartRo)
    cartRo.getElementsByClassName('btn-danger')[0].addEventListener('click',function(event){
        var buttonlicked=event.target;
        buttonlicked.parentElement.parentElement.remove();
        updateCarttotal();});
    cartRo.getElementsByClassName('cart-quantity-input')[0].addEventListener('change',quantitychanged)   
}
