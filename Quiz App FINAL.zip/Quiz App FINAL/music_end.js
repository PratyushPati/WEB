const username=document.getElementById("user");
const saveScoreBtn=document.getElementById("saveScoreBtn");
const finalScore=document.getElementById("finalScore");
const mostRecentScore=localStorage.getItem('mostRecentScore');

const HighScoresM=JSON.parse(localStorage.getItem("HighScoresM"))||[];
const max_high_score=5;

/* app process*/
finalScore.innerText=mostRecentScore;
username.addEventListener("keyup",()=>{
    saveScoreBtn.disabled= !username.value;
});
saveHighScore=(e)=>{
    e.preventDefault();
    const score={
        score:mostRecentScore,
        name:username.value
    };
    HighScoresM.push(score);
    HighScoresM.sort((a,b)=>{
        return b.score-a.score;
    });
    HighScoresM.splice(5);
    localStorage.setItem("HighScoresM",JSON.stringify(HighScoresM));
    init();
}
/*  Share Button functions*/

const facebookBtn=document.querySelector(".facebook-btn");
const twitterBtn=document.querySelector(".twitter-btn");
const whatsappBtn=document.querySelector(".whatsapp-btn");

function init(){
    let posturl=encodeURI(document.location.href);
    let postTitle=encodeURI(username.value+" scored "+mostRecentScore+" in Music Quiz");
    console.log(postTitle);
    facebookBtn.setAttribute("href",`https://www.facebook.com/sharer.php?u=${posturl}`); 
    twitterBtn.setAttribute("href",`https://twitter.com/share?url=${posturl}&text=${postTitle}`); 
    whatsappBtn.setAttribute("href",`https://wa.me/?text=${postTitle} ${posturl}`); 
}