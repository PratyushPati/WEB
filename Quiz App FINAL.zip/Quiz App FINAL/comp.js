const question=document.getElementById("question");
const choices=Array.from(document.getElementsByClassName("choice-text"));
const qCounterText=document.getElementById('questionCounter');
const scoreText=document.getElementById('score');

let currentq={};
let acceptingAnswers=false;
let score=0;
let qCounter=0;
let availaleQ=[];

let questions=[
    {
        question:"Which of these is not a peripheral, in computer terms?",
        choice1:"Monitor",
        choice2:"Mouse",
        choice3:"Keyboard",
        choice4:"Motherboard",
        answer: 4
    },
    {
        question:"What operating system did Google develop?",
        choice1:"Windows",
        choice2:"iOS",
        choice3:"Android",
        choice4:"BlackBerryOS",
        answer: 3
    },
    {
        question:"Which of these was the first supercomputer?",
        choice1:"CDC 6600",
        choice2:"ENIAC",
        choice3:"Sierra",
        choice4:"Cray-1",
        answer: 1
    },
    {
        question:"Which of these was the first personal computer?",
        choice1:"Osborne 1",
        choice2:"Apple Lisa",
        choice3:"Apple I",
        choice4:"Altair",
        answer: 4
    },
    {
        question:"In what year was Google founded?",
        choice1:"2001",
        choice2:"1995",
        choice3:"1998",
        choice4:"1989",
        answer: 3
    }
];

const correct_bonus=10;
const max_questions=5;

startgame=()=>{
    qCounter=0;
    score=0;
    availaleQ=[...questions];
    getnewq();
};
getnewq=()=>{
    if(availaleQ.length===0||qCounter>=max_questions){
        localStorage.setItem("mostRecentScore",score);
        return window.location.assign("comp_end.html");
    }
    qCounter++;
    qCounterText.innerHTML=qCounter+"/"+max_questions;
   const questionIndex= Math.floor(Math.random()*availaleQ.length);
   currentq=availaleQ[questionIndex];
   question.innerText=currentq.question;

   choices.forEach(choice=>{
       const number=choice.dataset['number'];
       choice.innerText=currentq['choice'+number];
   });
   availaleQ.splice(questionIndex,1);
   acceptingAnswers=true;

};
choices.forEach(choice=>{
    choice.addEventListener("click",e=>{
        if(!acceptingAnswers)return;
        acceptingAnswers=false;
        const selectedChoice=e.target;
        const selectedAnswer=selectedChoice.dataset["number"];

        const classToApply=(selectedAnswer== currentq.answer)?"correct":"incorrect";
        if(classToApply==="correct"){
            incrementScore(correct_bonus);
        }
        selectedChoice.parentElement.classList.add(classToApply);
        setTimeout(()=>{      
            selectedChoice.parentElement.classList.remove(classToApply);
            getnewq();
        },1000);
  
    });
});
incrementScore=num=>{
    score+=num;
    scoreText.innerText=score;
};
startgame();
