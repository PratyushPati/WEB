const highScoreList= document.getElementById("highScoreList");
const HighScoresC=JSON.parse(localStorage.getItem("HighScoresC"))||[];

highScoreList.innerHTML=HighScoresC.map(score=>{ return `<li class="high-score">${score.name} - ${score.score}</li>`;});
