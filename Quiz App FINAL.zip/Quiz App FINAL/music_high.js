const highScoreList= document.getElementById("highScoreList");
const HighScoresM=JSON.parse(localStorage.getItem("HighScoresM"))||[];

highScoreList.innerHTML=HighScoresM.map(score=>{ return `<li class="high-score">${score.name} - ${score.score}</li>`;});
