const highScoreList= document.getElementById("highScoreList");
const HighScoresS=JSON.parse(localStorage.getItem("HighScoresS"))||[];

highScoreList.innerHTML=HighScoresS.map(score=>{ return `<li class="high-score">${score.name} - ${score.score}</li>`;});
