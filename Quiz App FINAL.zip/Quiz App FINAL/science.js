const question=document.getElementById("question");
const choices=Array.from(document.getElementsByClassName("choice-text"));
const qCounterText=document.getElementById('questionCounter');
const scoreText=document.getElementById('score');

let currentq={};
let acceptingAnswers=false;
let score=0;
let qCounter=0;
let availaleQ=[];

let questions=[
    {
        question:"Which of these chemical elements is heavier than iron?",
        choice1:"Gold",
        choice2:"Carbon",
        choice3:"Manganese",
        choice4:"Potassium",
        answer: 1
    },
    {
        question:"A baby blue whale drinks this many liters of milk per day:",
        choice1:"10",
        choice2:"190",
        choice3:"50",
        choice4:"500",
        answer: 2
    },
    {
        question:"In physics, for every action there is an equal and opposite what?",
        choice1:"Subtraction",
        choice2:"Reaction",
        choice3:"Distraction",
        choice4:"Impaction",
        answer: 2
    },
    {
        question:"When was the first plastic made of artificial materials patented?",
        choice1:"2003",
        choice2:"1909",
        choice3:"1920",
        choice4:"1945",
        answer: 2
    },
    {
        question:"The layer of the atmosphere in which weather occurs is called the:",
        choice1:"Ionosphere",
        choice2:"Troposphere",
        choice3:"Mesosphere",
        choice4:"Stratosphere",
        answer: 2
    }
];

const correct_bonus=10;
const max_questions=5;

startgame=()=>{
    qCounter=0;
    score=0;
    availaleQ=[...questions];
    getnewq();
};
getnewq=()=>{
    if(availaleQ.length===0||qCounter>=max_questions){
        localStorage.setItem("mostRecentScore",score);
        return window.location.assign("science_end.html");
    }
    qCounter++;
    qCounterText.innerHTML=qCounter+"/"+max_questions;
   const questionIndex= Math.floor(Math.random()*availaleQ.length);
   currentq=availaleQ[questionIndex];
   question.innerText=currentq.question;

   choices.forEach(choice=>{
       const number=choice.dataset['number'];
       choice.innerText=currentq['choice'+number];
   });
   availaleQ.splice(questionIndex,1);
   acceptingAnswers=true;

};
choices.forEach(choice=>{
    choice.addEventListener("click",e=>{
        if(!acceptingAnswers)return;
        acceptingAnswers=false;
        const selectedChoice=e.target;
        const selectedAnswer=selectedChoice.dataset["number"];

        const classToApply=(selectedAnswer== currentq.answer)?"correct":"incorrect";
        if(classToApply==="correct"){
            incrementScore(correct_bonus);
        }
        selectedChoice.parentElement.classList.add(classToApply);
        setTimeout(()=>{      
            selectedChoice.parentElement.classList.remove(classToApply);
            getnewq();
        },1000);
  
    });
});
incrementScore=num=>{
    score+=num;
    scoreText.innerText=score;
};
startgame();
