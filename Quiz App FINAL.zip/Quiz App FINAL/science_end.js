const username=document.getElementById("user");
const saveScoreBtn=document.getElementById("saveScoreBtn");
const finalScore=document.getElementById("finalScore");
const mostRecentScore=localStorage.getItem('mostRecentScore');

const HighScoresS=JSON.parse(localStorage.getItem("HighScoresS"))||[];
const max_high_score=5;

/* app process*/
finalScore.innerText=mostRecentScore;
username.addEventListener("keyup",()=>{
    saveScoreBtn.disabled= !username.value;
});
saveHighScore=(e)=>{
    e.preventDefault();
    const score={
        score:mostRecentScore,
        name:username.value
    };
    HighScoresS.push(score);
    HighScoresS.sort((a,b)=>{
        return b.score-a.score;
    });
    HighScoresS.splice(5);
    localStorage.setItem("HighScoresS",JSON.stringify(HighScoresS));
    init();
}
/*  Share Button functions*/

const facebookBtn=document.querySelector(".facebook-btn");
const twitterBtn=document.querySelector(".twitter-btn");
const whatsappBtn=document.querySelector(".whatsapp-btn");

function init(){
    let posturl=encodeURI(document.location.href);
    let postTitle=encodeURI(username.value+" scored "+mostRecentScore+" in Science Quiz");
    console.log(postTitle);
    facebookBtn.setAttribute("href",`https://www.facebook.com/sharer.php?u=${posturl}`); 
    twitterBtn.setAttribute("href",`https://twitter.com/share?url=${posturl}&text=${postTitle}`); 
    whatsappBtn.setAttribute("href",`https://wa.me/?text=${postTitle} ${posturl}`); 
}