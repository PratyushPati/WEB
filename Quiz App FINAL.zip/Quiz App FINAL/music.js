const question=document.getElementById("question");
const choices=Array.from(document.getElementsByClassName("choice-text"));
const qCounterText=document.getElementById('questionCounter');
const scoreText=document.getElementById('score');

let currentq={};
let acceptingAnswers=false;
let score=0;
let qCounter=0;
let availaleQ=[];

let questions=[
    {
        question:"Which of the following instruments does not employ valves to change pitch?",
        choice1:"Trombone",
        choice2:"Flugelhorn",
        choice3:"Flute",
        choice4:"Trumpet",
        answer: 1
    },
    {
        question:"Which of these musical movements did Ludwig van Beethoven help introduce?",
        choice1:"Classicism",
        choice2:"Lyricism",
        choice3:"Idealism",
        choice4:"Romanticism",
        answer: 4
    },
    {
        question:"Which album has sold the most copies of all time worldwide?",
        choice1:"Pink Floyd - Dark Side of the Moon",
        choice2:"Fleetwood Mac - Rumours",
        choice3:"Michael Jackson - Thriller",
        choice4:"Celine Dion - Falling Into You",
        answer: 3
    },
    {
        question:"Which famous rock band had the hit song Hotel California?",
        choice1:"The Eagles",
        choice2:"The Rolling Stones",
        choice3:"Creedance Clearwater Revival",
        choice4:"Aerosmith",
        answer: 1
    },
    {
        question:"In which country was singer Rihanna born?",
        choice1:"USA",
        choice2:"Dominican Republic",
        choice3:"Barbados",
        choice4:"Puerto Rico",
        answer: 3
    }
];

const correct_bonus=10;
const max_questions=5;

startgame=()=>{
    qCounter=0;
    score=0;
    availaleQ=[...questions];
    getnewq();
};
getnewq=()=>{
    if(availaleQ.length===0||qCounter>=max_questions){
        localStorage.setItem("mostRecentScore",score);
        return window.location.assign("music_end.html");
    }
    qCounter++;
    qCounterText.innerHTML=qCounter+"/"+max_questions;
   const questionIndex= Math.floor(Math.random()*availaleQ.length);
   currentq=availaleQ[questionIndex];
   question.innerText=currentq.question;

   choices.forEach(choice=>{
       const number=choice.dataset['number'];
       choice.innerText=currentq['choice'+number];
   });
   availaleQ.splice(questionIndex,1);
   acceptingAnswers=true;

};
choices.forEach(choice=>{
    choice.addEventListener("click",e=>{
        if(!acceptingAnswers)return;
        acceptingAnswers=false;
        const selectedChoice=e.target;
        const selectedAnswer=selectedChoice.dataset["number"];

        const classToApply=(selectedAnswer== currentq.answer)?"correct":"incorrect";
        if(classToApply==="correct"){
            incrementScore(correct_bonus);
        }
        selectedChoice.parentElement.classList.add(classToApply);
        setTimeout(()=>{      
            selectedChoice.parentElement.classList.remove(classToApply);
            getnewq();
        },1000);
  
    });
});
incrementScore=num=>{
    score+=num;
    scoreText.innerText=score;
};
startgame();
